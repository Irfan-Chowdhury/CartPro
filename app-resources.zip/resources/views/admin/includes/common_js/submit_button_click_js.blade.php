$("#submitButton").on("click",function(e){
    $('#submitButton').text('Saving ...');
});
