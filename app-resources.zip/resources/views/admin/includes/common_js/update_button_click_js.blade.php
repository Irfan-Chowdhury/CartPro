$("#updateButton").on("click",function(e){
    $('#updateButton').text('Updating ...');
});
