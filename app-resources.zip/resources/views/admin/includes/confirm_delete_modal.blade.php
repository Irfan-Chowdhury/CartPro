<div class="modal fade" id="bulkDeleteModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h2 class="modal-title">{{trans('file.Confirmation')}}</h2>
                <button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>
            <div class="modal-footer">
                <button type="button" id="bulkDeleteAll" class="btn btn-danger text-center">@lang('file.Delete')</button>
            </div>
        </div>
    </div>
  </div>

