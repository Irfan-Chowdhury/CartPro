<?php

namespace App\Contracts\Category;

use App\Contracts\BaseContract;

interface CategoryProductContract extends BaseContract
{

}

?>
