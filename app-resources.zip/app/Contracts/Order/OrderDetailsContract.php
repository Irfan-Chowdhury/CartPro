<?php

namespace App\Contracts\Order;

interface OrderDetailsContract
{
    public function destroy($id);
}

?>
