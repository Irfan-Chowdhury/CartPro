<?php

namespace App\Contracts\Menu;

use App\Contracts\BaseContract;

interface MenuContract extends BaseContract
{

}
