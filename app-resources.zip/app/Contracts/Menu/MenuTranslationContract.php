<?php

namespace App\Contracts\Menu;

use App\Contracts\BaseContract;

interface MenuTranslationContract extends BaseContract
{
    
}
