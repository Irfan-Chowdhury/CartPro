<?php

namespace App\Contracts\Coupon;

use App\Contracts\BaseContract;

interface CouponTranslationContract extends BaseContract
{
    // public function destroy($coupon_id);

    // public function bulkAction($type, $ids);
}
