<?php

namespace App\Contracts\Coupon;

use App\Contracts\BaseContract;

interface CouponContract extends BaseContract
{
    // public function getById($id);

    // public function active($id);

    // public function inactive($id);

    // public function destroy($id);

    // public function bulkAction($type, $ids);
}
