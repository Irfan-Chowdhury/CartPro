<?php

namespace App\Contracts\Product;

use App\Contracts\BaseContract;

interface ProductAttributeValueContract extends BaseContract
{

}
