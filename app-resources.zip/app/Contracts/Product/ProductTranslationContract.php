<?php

namespace App\Contracts\Product;

use App\Contracts\BaseContract;

interface ProductTranslationContract extends BaseContract
{

}
