<?php

namespace App\Contracts\Product;

use App\Contracts\BaseContract;

interface ProductTagContract extends BaseContract
{

}
