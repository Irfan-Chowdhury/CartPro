// Some Common Word
let recordPerPage = "{{__('Records per page')}}";
let showing       = "{{trans('file.Showing')}}";
let search        = "{{trans('file.Search')}}";
let previous      = "{{trans('file.Previous')}}";
let next          = "{{trans('file.Next')}}";
