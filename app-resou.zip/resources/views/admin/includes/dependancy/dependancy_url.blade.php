<input type="text" class="col-md-12 form-control" name="url" id="url" placeholder="Put URL">
