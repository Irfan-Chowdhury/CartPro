@php
    // if (!Session::put('currency_code') && !Session::has('currency_symbol') && !Session::has('currency_rate')) {
    //     $DEFAULT_CURRENCY_CODE = env('DEFAULT_CURRENCY_CODE') ?? 'USD';
    //     $CHANGE_CURRENCY_SYMBOL= env('DEFAULT_CURRENCY_SYMBOL') ?? '$';
    //     $CHANGE_CURRENCY_RATE  = 1.00;

    //     Session::put('currency_code',$DEFAULT_CURRENCY_CODE);
    // }
    // $DEFAULT_CURRENCY_CODE  = Session::get('currency_code');
    // $CHANGE_CURRENCY_SYMBOL = Session::get('currency_symbol');
    // $CHANGE_CURRENCY_RATE   = Session::get('currency_rate');
@endphp
