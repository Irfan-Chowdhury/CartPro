<?php

namespace App\Contracts\Role;

use App\Contracts\BaseContract;

interface RoleContract extends BaseContract
{

}
